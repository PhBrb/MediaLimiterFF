const DEFAULT_SETTINGS = {
  shortsLimitSeconds: 600,
  siteCostSeconds: 30,
  extraSites: []
};

const ROLLING_WINDOW_MS = 60 * 60 * 1000;
const SHORTS_URL_PATTERN = /^https:\/\/(www\.|m\.)?youtube\.com\/(shorts|live\/shorts)/i;

let trackedTabId = null;
let trackedActiveSince = 0;
let trackedVisible = true;
let tickTimer = null;
let blockedTabIds = new Set();

async function getSettings() {
  const stored = await browser.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...(stored.settings || {}) };
}

async function getUsage() {
  const stored = await browser.storage.local.get("usage");
  const usage = stored.usage || { events: [] };
  usage.events = (usage.events || []).filter(e => Date.now() - e.t < ROLLING_WINDOW_MS);
  return usage;
}

async function saveUsage(usage) {
  await browser.storage.local.set({ usage });
}

function recordEvent(usage, seconds) {
  usage.events.push({ t: Date.now(), s: seconds });
}

async function usedSeconds(usage) {
  return usage.events.reduce((sum, e) => sum + (e.s || 0), 0);
}

function isShortsUrl(url) {
  return SHORTS_URL_PATTERN.test(url || "");
}

function normalizeSiteInput(input) {
  let value = input.trim().toLowerCase();
  if (!value) return null;
  if (value.includes("://")) {
    try {
      value = new URL(value).hostname;
    } catch (e) {
      return null;
    }
  }
  value = value.replace(/^www\./, "");
  if (!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(value)) return null;
  return value;
}

function matchesExtraSite(url, sites) {
  let hostname;
  try {
    hostname = new URL(url).hostname.toLowerCase().replace(/^www\./, "");
  } catch (e) {
    return false;
  }
  return sites.some(s => hostname === s || hostname.endsWith("." + s));
}

async function isTrackedUrl(url) {
  if (isShortsUrl(url)) return true;
  const settings = await getSettings();
  return settings.extraSites.length > 0 && matchesExtraSite(url, settings.extraSites);
}

function buildBlockPageUrl(remainingSeconds) {
  return browser.runtime.getURL("blockpage.html") + "?remaining=" + encodeURIComponent(Math.ceil(remainingSeconds));
}

async function checkAndEnforce(tabId) {
  const settings = await getSettings();
  const usage = await getUsage();
  const used = await usedSeconds(usage);
  const limit = settings.shortsLimitSeconds;
  if (used >= limit) {
    await blockTab(tabId, limit - used);
    return true;
  }
  return false;
}

async function blockTab(tabId, remainingSeconds) {
  blockedTabIds.add(tabId);
  try {
    await browser.tabs.update(tabId, { url: buildBlockPageUrl(remainingSeconds) });
  } catch (e) {
  }
}

function startTicking() {
  if (tickTimer === null) {
    tickTimer = setInterval(tick, 1000);
  }
}

function stopTickingIfIdle() {
  if (trackedTabId === null && tickTimer !== null) {
    clearInterval(tickTimer);
    tickTimer = null;
  }
}

async function isTabForeground(tabId) {
  if (!trackedVisible) return false;
  try {
    const tab = await browser.tabs.get(tabId);
    if (!tab.active) return false;
    const win = await browser.windows.get(tab.windowId);
    return win.focused;
  } catch (e) {
    return false;
  }
}

async function tick() {
  if (trackedTabId === null) {
    stopTickingIfIdle();
    return;
  }
  const now = Date.now();
  const elapsed = Math.min((now - trackedActiveSince) / 1000, 60);
  trackedActiveSince = now;
  if (elapsed <= 0) return;

  if (!(await isTabForeground(trackedTabId))) return;

  const usage = await getUsage();
  recordEvent(usage, elapsed);
  await saveUsage(usage);

  const settings = await getSettings();
  const used = await usedSeconds(usage);
  if (used >= settings.shortsLimitSeconds) {
    const tabId = trackedTabId;
    stopTracking();
    await blockTab(tabId, settings.shortsLimitSeconds - used);
  }
}

function stopTracking() {
  trackedTabId = null;
  trackedActiveSince = 0;
  trackedVisible = true;
  stopTickingIfIdle();
}

async function injectVisibilityReporter(tabId) {
  try {
    await browser.tabs.executeScript(tabId, {
      file: "visibility-reporter.js",
      runAt: "document_idle"
    });
  } catch (e) {
  }
}

async function startTracking(tabId, injectReporter) {
  if (trackedTabId !== null && trackedTabId !== tabId) {
    await tick();
    stopTracking();
  }
  trackedTabId = tabId;
  trackedVisible = true;
  trackedActiveSince = Date.now();
  if (injectReporter) {
    await injectVisibilityReporter(tabId);
  }
  startTicking();
}

async function onNavigation(details) {
  const url = details.url || "";

  if (details.frameId !== 0) return;

  if (await isTrackedUrl(url)) {
    if (await checkAndEnforce(details.tabId)) return;
    if (trackedTabId !== details.tabId) {
      const settings = await getSettings();
      const needsInjection = !isShortsUrl(url);
      await startTracking(details.tabId, needsInjection);
    }
    return;
  }

  if (trackedTabId === details.tabId) {
    await tick();
    stopTracking();
  }
}

async function syncTrackingWithActiveTab() {
  try {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) return;
    const tab = tabs[0];
    if (await isTrackedUrl(tab.url)) {
      if (trackedTabId !== tab.id) {
        const needsInjection = !isShortsUrl(tab.url);
        await startTracking(tab.id, needsInjection);
      }
    } else if (trackedTabId === tab.id) {
      await tick();
      stopTracking();
    }
  } catch (e) {
  }
}

browser.webNavigation.onCommitted.addListener(onNavigation);

browser.webNavigation.onHistoryStateUpdated.addListener(onNavigation);

browser.windows.onFocusChanged.addListener(async windowId => {
  trackedActiveSince = Date.now();
  await syncTrackingWithActiveTab();
});

browser.tabs.onRemoved.addListener(tabId => {
  if (trackedTabId === tabId) {
    stopTracking();
  }
  blockedTabIds.delete(tabId);
});

browser.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "complete" && trackedTabId === tabId) {
    trackedActiveSince = Date.now();
  }
  if (changeInfo.url) {
    onNavigation({ tabId, url: changeInfo.url, frameId: 0 });
  }
});

browser.tabs.onActivated.addListener(async activeInfo => {
  if (trackedTabId !== null && trackedTabId !== activeInfo.tabId) {
    await tick();
    stopTracking();
  }
  await syncTrackingWithActiveTab();
});

browser.runtime.onMessage.addListener(async message => {
  if (message && message.type === "pageVisibility") {
    if (trackedTabId === null) return;
    if (message.visible) {
      if (!trackedVisible) {
        trackedVisible = true;
        trackedActiveSince = Date.now();
        startTicking();
      }
    } else {
      await tick();
      trackedVisible = false;
      trackedActiveSince = Date.now();
      stopTickingIfIdle();
    }
    return;
  }
  if (message && message.type === "getLimitStatus") {
    const settings = await getSettings();
    const usage = await getUsage();
    const used = await usedSeconds(usage);
    return {
      limit: settings.shortsLimitSeconds,
      used,
      remaining: Math.max(0, settings.shortsLimitSeconds - used)
    };
  }
  if (message && message.type === "resetUsage") {
    await browser.storage.local.set({ usage: { events: [] } });
    return { ok: true };
  }
});

browser.runtime.onInstalled.addListener(async () => {
  const settings = await getSettings();
  await browser.storage.local.set({ settings });
});

syncTrackingWithActiveTab();
